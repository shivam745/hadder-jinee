# Peter Answers: Virtual Tarot

https://www.francisenriquez.com/peter-answers

## What is Peter Answers?
Peter answers is a virtual tarot that can answer any question you throw at him. You have to ask him correctly or else Peter won't give the answers you desire. 

## How does it works?
You do this with a petition of "Peter please answer the following question" or "Peter please answer" before each time you ask a question. Petition correctly and he'll answer your question.

## How does it REALLY work?
You ARE Peter, so you decide how Peter answers. In the petition, you press the period (.) key then your answer. While typing, the petition will automatically be typed in. When finished typing your answer, press period again and manually finish out the petition. Ask your question and your answer will appear.
### Example:

#### What you type:  
**Petition:** .Mark, Jeff, and Peter. following question  
**Question:** Who is in this room right now?  
#### What you see:  
**Petition:** Peter please answer the following question  
**Question:** Who is in this room right now?  
**Peter says Mark, Jeff, and Peter**  

